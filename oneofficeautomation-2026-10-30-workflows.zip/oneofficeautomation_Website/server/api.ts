// All /api/* requests are handled here (called by the Express server in index.ts).
import { DUMMY_HASH, hashPassword, signSession, verifyPassword, verifySession } from './_lib/crypto';
import { fieldErrors, leadSchemas, loginSchema, registerSchema } from './_lib/validation';
import { handleAdmin } from './_lib/admin';
import { handlePortal, customerStatus } from './_lib/portal';
import { notifyTeam, sendMail } from './_lib/mail';
import { STAGES, legacyStatus, logActivity, now, sign, siteUrl } from './_lib/workflow';
import { allow } from './_lib/http';
import type { Env } from './_lib/http';

type Customer = { id: string; first_name: string; last_name: string; email: string; company: string; country: string; plan: string; password_hash: string; created_at: string };

const COOKIE = 'ooa_session';
const SESSION_DAYS = 7;

function json(body: unknown, status = 200, extra: HeadersInit = {}): Response {
  const headers = new Headers(extra);
  headers.set('Content-Type', 'application/json; charset=utf-8');
  headers.set('Cache-Control', 'no-store');
  headers.set('X-Content-Type-Options', 'nosniff');
  return new Response(JSON.stringify(body), { status, headers });
}

const sessionCookie = (token: string, maxAgeSeconds: number) =>
  `${COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAgeSeconds}`;

function readCookie(req: Request, name: string): string | null {
  const header = req.headers.get('Cookie') ?? '';
  for (const part of header.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return v.join('=');
  }
  return null;
}

const publicUser = (c: Customer, meta?: { status: string; newsletter: number } | null) => ({
  id: c.id, firstName: c.first_name, lastName: c.last_name, email: c.email,
  company: c.company, country: c.country, plan: c.plan, createdAt: c.created_at,
  status: meta?.status ?? (c.plan === 'community' ? 'free' : 'trial'), newsletter: !!meta?.newsletter,
});

async function readJson(req: Request): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    return null;
  }
}

async function currentCustomer(env: Env, req: Request): Promise<Customer | null> {
  const token = readCookie(req, COOKIE);
  const id = token ? await verifySession(token, env.JWT_SECRET) : null;
  if (!id) return null;
  return env.DB.prepare('SELECT * FROM customers WHERE id = ?1').bind(id).first<Customer>();
}

export async function handleApi(request: Request, env: Env): Promise<Response> {
  try {
    if (!env.JWT_SECRET || env.JWT_SECRET.length < 32) {
      return json({ error: 'The server isn’t configured yet (JWT_SECRET is missing).' }, 500);
    }
    const url = new URL(request.url);
    const route = `${request.method} ${url.pathname.replace(/\/+$/, '')}`;

    // CSRF protection: cross-site HTML forms can't send JSON.
    if ((request.method === 'POST' || request.method === 'PUT' || request.method === 'PATCH') && !(request.headers.get('Content-Type') ?? '').toLowerCase().startsWith('application/json')) {
      return json({ error: 'Send JSON.' }, 415);
    }

    if (route === 'GET /api/health') return json({ ok: true });

    // Published content overrides: one small JSON map, cached for a few seconds.
    if (route === 'GET /api/content') {
      const rows = await env.DB.prepare('SELECT `key`, value FROM content').all<{ key: string; value: string }>();
      const out: Record<string, unknown> = {};
      for (const r of rows.results) out[r.key] = JSON.parse(r.value);
      return json(out, 200, { 'Cache-Control': 'public, max-age=5' });
    }

    const adminResponse = await handleAdmin(request, env, route, url);
    if (adminResponse) return adminResponse;
    const portalResponse = await handlePortal(request, env, route, url);
    if (portalResponse) return portalResponse;

    if (route === 'POST /api/auth/register') {
      if (!(await allow(env, request, 'auth', 20, 900))) return json({ error: 'Too many attempts. Please wait a few minutes and try again.' }, 429);
      const parsed = registerSchema.safeParse(await readJson(request));
      if (!parsed.success) return json(fieldErrors(parsed.error), 400);
      const d = parsed.data;
      const existing = await env.DB.prepare('SELECT id FROM customers WHERE email = ?1').bind(d.email).first();
      if (existing) {
        return json({ error: 'An account with this email already exists. Try signing in.', fields: { email: 'This email is already registered.' } }, 409);
      }
      const customer: Customer = {
        id: crypto.randomUUID(), first_name: d.firstName, last_name: d.lastName, email: d.email, company: d.company,
        country: d.country, plan: d.plan, password_hash: await hashPassword(d.password), created_at: new Date().toISOString(),
      };
      try {
        await env.DB.prepare(
          `INSERT INTO customers (id, first_name, last_name, email, company, country, plan, password_hash, created_at)
           VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)`,
        ).bind(customer.id, customer.first_name, customer.last_name, customer.email, customer.company, customer.country, customer.plan, customer.password_hash, customer.created_at).run();
      } catch (err) {
        if (/UNIQUE|Duplicate entry/.test(String(err))) return json({ error: 'An account with this email already exists. Try signing in.', fields: { email: 'This email is already registered.' } }, 409);
        throw err;
      }
      const status = customer.plan === 'enterprise' ? 'enterprise_pending' : customer.plan === 'community' ? 'free' : 'trial';
      await env.DB.prepare('INSERT INTO customer_meta (customer_id, status, newsletter, updated_at) VALUES (?1, ?2, 0, ?3)').bind(customer.id, status, now()).run();
      await logActivity(env, 'customer', customer.id, `${customer.first_name} ${customer.last_name}`, 'signed_up', null, status);
      const base = siteUrl(env, request);
      await sendMail(env, customer.email, 'welcome', { name: customer.first_name, plan: customer.plan[0].toUpperCase() + customer.plan.slice(1), link: `${base}/signin` });
      await notifyTeam(env, { type: customer.plan === 'enterprise' ? 'Enterprise sign-up (needs sales follow-up)' : 'sign-up', name: `${customer.first_name} ${customer.last_name} (${customer.company})`, email: customer.email, link: `${base}/admin/customers` });
      const token = await signSession(customer.id, env.JWT_SECRET, SESSION_DAYS);
      return json({ user: publicUser(customer, { status, newsletter: 0 }) }, 201, { 'Set-Cookie': sessionCookie(token, SESSION_DAYS * 86400) });
    }

    if (route === 'POST /api/auth/login') {
      if (!(await allow(env, request, 'auth', 20, 900))) return json({ error: 'Too many attempts. Please wait a few minutes and try again.' }, 429);
      const parsed = loginSchema.safeParse(await readJson(request));
      if (!parsed.success) return json(fieldErrors(parsed.error), 400);
      const customer = await env.DB.prepare('SELECT * FROM customers WHERE email = ?1').bind(parsed.data.email).first<Customer>();
      const ok = await verifyPassword(parsed.data.password, customer?.password_hash ?? DUMMY_HASH);
      if (!customer || !ok) return json({ error: 'Email or password is incorrect.' }, 401);
      const meta = await customerStatus(env, customer.id);
      if (meta && (meta.status === 'suspended' || meta.status === 'closed')) return json({ error: `This account is ${meta.status}. Please contact support@oneofficeautomation.com.` }, 403);
      const token = await signSession(customer.id, env.JWT_SECRET, SESSION_DAYS);
      return json({ user: publicUser(customer, meta) }, 200, { 'Set-Cookie': sessionCookie(token, SESSION_DAYS * 86400) });
    }

    if (route === 'POST /api/auth/logout') {
      return json({ ok: true }, 200, { 'Set-Cookie': sessionCookie('', 0) });
    }

    if (route === 'GET /api/auth/me') {
      const customer = await currentCustomer(env, request);
      if (!customer) return json({ error: 'Not signed in.' }, 401);
      const meta = await customerStatus(env, customer.id);
      if (meta && (meta.status === 'suspended' || meta.status === 'closed')) return json({ error: 'Not signed in.' }, 401, { 'Set-Cookie': sessionCookie('', 0) });
      return json({ user: publicUser(customer, meta) });
    }

    const lead = route.match(/^POST \/api\/leads\/(demo|partner|newsletter|career)$/);
    if (lead) {
      if (!(await allow(env, request, 'leads', 30, 3600))) return json({ error: 'Too many submissions. Please try again later.' }, 429);
      const kind = lead[1] as keyof typeof leadSchemas;
      const parsed = leadSchemas[kind].safeParse(await readJson(request));
      if (!parsed.success) return json(fieldErrors(parsed.error), 400);
      const d = parsed.data as Record<string, string>;
      const base = siteUrl(env, request);
      if (kind === 'newsletter') {
        // One row per email address: subscribing again simply re-activates it.
        const existing = await env.DB.prepare("SELECT l.id, m.stage FROM leads l LEFT JOIN lead_meta m ON m.lead_id = l.id WHERE l.kind = 'newsletter' AND JSON_UNQUOTE(JSON_EXTRACT(l.payload, '$.nl')) = ?1 LIMIT 1").bind(d.nl).first<{ id: string; stage: string | null }>();
        if (existing) {
          if (existing.stage === 'unsubscribed') {
            await env.DB.prepare("UPDATE lead_meta SET stage = 'subscribed', updated_at = ?2 WHERE lead_id = ?1").bind(existing.id, now()).run();
            await logActivity(env, 'lead', existing.id, d.nl, 'stage', 'unsubscribed', 'subscribed', 'Subscribed again');
          }
          return json({ ok: true }, 201);
        }
      }
      const id = crypto.randomUUID();
      const stage = STAGES[kind][0].id;
      await env.DB.batch([
        env.DB.prepare('INSERT INTO leads (id, kind, status, payload, created_at) VALUES (?1, ?2, ?3, ?4, ?5)').bind(id, kind, legacyStatus(kind, stage), JSON.stringify(d), now()),
        env.DB.prepare('INSERT INTO lead_meta (lead_id, stage, updated_at) VALUES (?1, ?2, ?3)').bind(id, stage, now()),
      ]);
      const who = kind === 'demo' ? `${d.fn} ${d.ln}` : kind === 'partner' ? d.pn : kind === 'career' ? d.cn : d.nl;
      await logActivity(env, 'lead', id, who, 'submitted', null, stage);
      const admin = `${base}/admin/records/${id}`;
      if (kind === 'demo') {
        await sendMail(env, d.em, 'demo_received', { name: d.fn });
        await notifyTeam(env, { type: 'demo request', name: `${d.fn} ${d.ln} (${d.co})`, email: d.em, link: admin });
      } else if (kind === 'partner') {
        await sendMail(env, d.pe, 'partner_received', { name: d.pn, company: d.pc });
        await notifyTeam(env, { type: 'partner application', name: `${d.pn} (${d.pc})`, email: d.pe, link: admin });
      } else if (kind === 'career') {
        const statusLink = `${base}/application/${id}.${sign(env, 'app:' + id)}`;
        await sendMail(env, d.ce, 'career_received', { name: d.cn, role: d.crole || 'a role', statusLink });
        await notifyTeam(env, { type: 'job application', name: `${d.cn} (${d.crole || 'general'})`, email: d.ce, link: admin });
      } else {
        await sendMail(env, d.nl, 'newsletter_welcome', { unsubscribe: `${base}/unsubscribe?e=${encodeURIComponent(d.nl)}&s=${sign(env, 'nl:' + d.nl)}` });
      }
      return json({ ok: true }, 201);
    }

    return json({ error: 'Not found.' }, 404);
  } catch (err) {
    console.error(err);
    return json({ error: 'Something went wrong on our side. Please try again.' }, 500);
  }
}
