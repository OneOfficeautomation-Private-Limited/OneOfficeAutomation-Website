// Shared workflow rules: pipeline stages, the activity log, one-time links and signed links.
import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import type { Env } from './http';

/** Pipeline stages for each kind of form submission, in order. The first one is where new items start. */
export const STAGES: Record<string, { id: string; label: string; done?: boolean }[]> = {
  demo: [
    { id: 'new', label: 'New' }, { id: 'contacted', label: 'Contacted' }, { id: 'scheduled', label: 'Demo scheduled' },
    { id: 'done', label: 'Demo done' }, { id: 'won', label: 'Won', done: true }, { id: 'lost', label: 'Lost', done: true },
  ],
  partner: [
    { id: 'submitted', label: 'Submitted' }, { id: 'review', label: 'In review' },
    { id: 'approved', label: 'Approved', done: true }, { id: 'rejected', label: 'Rejected', done: true },
  ],
  career: [
    { id: 'new', label: 'New' }, { id: 'screening', label: 'Screening' }, { id: 'intro', label: 'Intro chat' }, { id: 'task', label: 'Practical task' },
    { id: 'offer', label: 'Offer' }, { id: 'hired', label: 'Hired', done: true }, { id: 'rejected', label: 'Not successful', done: true }, { id: 'withdrawn', label: 'Withdrawn', done: true },
  ],
  newsletter: [{ id: 'subscribed', label: 'Subscribed' }, { id: 'unsubscribed', label: 'Unsubscribed', done: true }],
};
export const PARTNER_LEVELS = ['Registered', 'Certified', 'Strategic'];
export const PARTNER_STATUSES = ['onboarding', 'active', 'inactive'];
export const PARTNER_CHECKLIST = [
  { id: 'agreement', label: 'Partner agreement signed' },
  { id: 'training', label: 'Partner training completed' },
  { id: 'sandbox', label: 'Sandbox environment issued' },
];
export const CUSTOMER_STATUSES = ['free', 'trial', 'paid', 'enterprise_pending', 'enterprise', 'suspended', 'closed'];
export const CUSTOMER_STATUS_LABEL: Record<string, string> = { free: 'Free', trial: 'Trial', paid: 'Paid', enterprise_pending: 'Enterprise (pending)', enterprise: 'Enterprise', suspended: 'Suspended', closed: 'Closed' };
export const REQUEST_KINDS = ['community', 'plan', 'deletion', 'event'];

/** Maps the old three statuses (new, contacted, closed) to a stage, for submissions made before workflows existed. */
export function legacyStage(kind: string, status: string): string {
  const first = STAGES[kind]?.[0]?.id ?? 'new';
  if (kind === 'newsletter') return 'subscribed';
  if (status === 'contacted') return kind === 'partner' ? 'review' : kind === 'career' ? 'screening' : 'contacted';
  if (status === 'closed') return kind === 'demo' ? 'done' : kind === 'partner' ? 'review' : kind === 'career' ? 'screening' : first;
  return first;
}
/** Keeps the old status column meaningful (new, contacted, closed) for exports made before workflows. */
export function legacyStatus(kind: string, stage: string): string {
  const s = STAGES[kind]?.find((x) => x.id === stage);
  if (!s || stage === STAGES[kind][0].id) return 'new';
  return s.done ? 'closed' : 'contacted';
}
export const stageLabel = (kind: string, stage: string) => STAGES[kind]?.find((s) => s.id === stage)?.label ?? stage;

export async function logActivity(env: Env, entity: string, entityId: string, actor: string, action: string, from: string | null = null, to: string | null = null, note: string | null = null) {
  await env.DB.prepare('INSERT INTO activity (entity, entity_id, actor, action, from_value, to_value, note, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)')
    .bind(entity, entityId, actor.slice(0, 120), action, from, to, note ? note.slice(0, 4000) : null, new Date().toISOString()).run();
}

/** Creates a one-time link token. Only its hash is stored. */
export async function createToken(env: Env, purpose: 'reset' | 'invite', userType: 'customer' | 'partner', userId: string, ttlSeconds: number): Promise<string> {
  const raw = randomBytes(32).toString('base64url');
  const hash = createHash('sha256').update(raw).digest('hex');
  await env.DB.prepare('INSERT INTO tokens (hash, purpose, user_type, user_id, expires_at, used, created_at) VALUES (?1, ?2, ?3, ?4, ?5, 0, ?6)')
    .bind(hash, purpose, userType, userId, Date.now() + ttlSeconds * 1000, new Date().toISOString()).run();
  return raw;
}
/** Uses up a one-time link token. Returns the user it belongs to, or null if it's invalid, used or expired. */
export async function consumeToken(env: Env, raw: string, userType: 'customer' | 'partner'): Promise<{ userId: string; purpose: string } | null> {
  if (!raw || raw.length > 100) return null;
  const hash = createHash('sha256').update(raw).digest('hex');
  const row = await env.DB.prepare('SELECT user_id, purpose, user_type, expires_at, used FROM tokens WHERE hash = ?1').bind(hash).first<{ user_id: string; purpose: string; user_type: string; expires_at: number; used: number }>();
  if (!row || row.used || row.user_type !== userType || Number(row.expires_at) < Date.now()) return null;
  await env.DB.prepare('UPDATE tokens SET used = 1 WHERE hash = ?1').bind(hash).run();
  return { userId: row.user_id, purpose: row.purpose };
}

/** Signed, non-expiring links (job application status, newsletter unsubscribe). */
export function sign(env: Env, value: string): string {
  return createHmac('sha256', env.JWT_SECRET).update(value).digest('base64url').slice(0, 22);
}
export function verifySigned(env: Env, value: string, sig: string): boolean {
  const a = Buffer.from(sign(env, value)); const b = Buffer.from(sig || '');
  return a.length === b.length && timingSafeEqual(a, b);
}

export function siteUrl(env: Env, req: Request): string {
  if (env.SITE_URL) return env.SITE_URL.replace(/\/+$/, '');
  const u = new URL(req.url);
  return `${u.protocol}//${u.host}`;
}

export const now = () => new Date().toISOString();
export const addDays = (days: number) => new Date(Date.now() + days * 86400000).toISOString().slice(0, 10);
