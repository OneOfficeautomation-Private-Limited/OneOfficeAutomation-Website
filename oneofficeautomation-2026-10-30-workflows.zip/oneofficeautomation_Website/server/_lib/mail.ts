// Sends the site's emails through SMTP (for example Zoho Mail) and records every attempt in email_log.
// If SMTP isn't configured yet, emails are logged as "skipped" and everything else keeps working.
import nodemailer from 'nodemailer';
import type { Transporter } from 'nodemailer';
import defaults from '../../src/cms/emails.defaults.json';
import type { Env } from './http';

let transport: Transporter | null = null;
let transportKey = '';

export function mailConfigured(env: Env): boolean {
  return !!(env.SMTP_HOST && env.SMTP_USER && env.SMTP_PASS);
}

function getTransport(env: Env): Transporter {
  const key = `${env.SMTP_HOST}|${env.SMTP_PORT}|${env.SMTP_USER}`;
  if (!transport || key !== transportKey) {
    const port = Number(env.SMTP_PORT || 465);
    transport = nodemailer.createTransport({ host: env.SMTP_HOST, port, secure: port === 465, auth: { user: env.SMTP_USER, pass: env.SMTP_PASS } });
    transportKey = key;
  }
  return transport;
}

/** Only for tests: send through a custom transport. */
export function setTestTransport(t: Transporter | null) { transport = t; transportKey = t ? 'test' : ''; }

const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c] as string);
const fill = (s: string, vars: Record<string, string>) => s.replace(/\{\{(\w+)\}\}/g, (_, k: string) => vars[k] ?? '');

function html(body: string): string {
  const paras = esc(body).split(/\n{2,}/).map((p) => `<p style="margin:0 0 14px">${p.replace(/\n/g, '<br>').replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" style="color:#1F74C9">$1</a>')}</p>`).join('');
  return `<!doctype html><html><body style="margin:0;background:#F4F6FD;font-family:Arial,Helvetica,sans-serif;color:#1B2350">
<div style="max-width:560px;margin:0 auto;padding:28px 16px"><div style="background:#1F2A5C;color:#fff;border-radius:14px 14px 0 0;padding:18px 24px;font-weight:bold;font-size:18px">OneOfficeAutomation</div>
<div style="background:#fff;border-radius:0 0 14px 14px;padding:24px;font-size:15px;line-height:1.6">${paras}</div>
<p style="color:#7F8BB8;font-size:12px;text-align:center;margin-top:16px">OneOfficeAutomation Private Limited</p></div></body></html>`;
}

async function templates(env: Env): Promise<Record<string, string>> {
  try {
    const row = await env.DB.prepare("SELECT value FROM content WHERE `key` = 'emails.templates'").first<{ value: string }>();
    return { ...defaults['emails.templates'], ...(row ? JSON.parse(row.value) : {}) };
  } catch {
    return defaults['emails.templates'];
  }
}

/** Sends one templated email. Never throws: failures are recorded in email_log. */
export async function sendMail(env: Env, to: string, template: string, vars: Record<string, string>): Promise<'sent' | 'skipped' | 'failed'> {
  const t = await templates(env);
  const subject = fill(t[`${template}_subject`] ?? template, vars).slice(0, 290);
  const body = fill(t[`${template}_body`] ?? '', vars).replace(/\n{3,}/g, '\n\n').trim();
  let status: 'sent' | 'skipped' | 'failed' = 'skipped';
  let error: string | null = null;
  if (!to) { status = 'failed'; error = 'No email address.'; }
  else if (mailConfigured(env) || transportKey === 'test') {
    try {
      await getTransport(env).sendMail({ from: env.MAIL_FROM || env.SMTP_USER, to, replyTo: env.NOTIFY_EMAIL || undefined, subject, text: body, html: html(body) });
      status = 'sent';
    } catch (err) {
      status = 'failed';
      error = String((err as Error).message || err).slice(0, 480);
    }
  } else {
    error = 'Email is not set up yet (SMTP settings missing).';
  }
  try {
    await env.DB.prepare('INSERT INTO email_log (to_email, subject, template, status, error, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6)')
      .bind(to.slice(0, 200), subject, template, status, error, new Date().toISOString()).run();
  } catch (err) {
    console.error('email_log', err);
  }
  return status;
}

/** Sends to the team address (NOTIFY_EMAIL), if one is set. */
export async function notifyTeam(env: Env, vars: Record<string, string>) {
  if (env.NOTIFY_EMAIL) await sendMail(env, env.NOTIFY_EMAIL, 'team_new', vars);
}
