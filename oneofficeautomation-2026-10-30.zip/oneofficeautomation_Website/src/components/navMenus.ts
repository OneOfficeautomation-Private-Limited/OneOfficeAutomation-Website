/* What each main-menu item shows when hovered. Resources builds its own menu from the CMS categories. */
export type MenuLink = { label: string; desc?: string; to: string; icon: string };
export type MenuSection = { heading: string; links: MenuLink[]; cols?: number };
export type MenuFeature = { kicker: string; title: string; text: string; cta: string; to: string; stat?: string };
export type Menu = { sections: MenuSection[]; feature: MenuFeature };

const ic = {
  overview: 'M4 5h16v14H4zM4 9h16M9 9v10',
  code: 'M8 7l-5 5 5 5M16 7l5 5-5 5',
  play: 'M7 4.5l12 7.5-12 7.5z',
  shield: 'M12 3l8 4v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7zM9 12l2 2 4-4',
  network: 'M12 3.5a2 2 0 110 4 2 2 0 010-4zM5 16.5a2 2 0 110 4 2 2 0 010-4zM19 16.5a2 2 0 110 4 2 2 0 010-4zM12 7.5v4.5M12 12l-6 4.5M12 12l6 4.5',
  doc: 'M6 3h9l4 4v14H6zM14 3v5h5M9 13h6M9 17h4',
  flow: 'M4 5h6v5H4zM14 14h6v5h-6zM7 10v3a2 2 0 002 2h5',
  spark: 'M12 3l1.8 4.7 4.7 1.8-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z',
  lock: 'M6 11h12v10H6zM8.5 11V8a3.5 3.5 0 017 0v3M12 15v2',
  bank: 'M3 10l9-6 9 6M5 10v9M19 10v9M9 10v9M15 10v9M3 21h18',
  heart: 'M12 20s-7-4.5-7-10a4 4 0 017-2.6A4 4 0 0119 10c0 5.5-7 10-7 10z',
  factory: 'M3 21V10l5 3V10l5 3V7l8 4v10z',
  cart: 'M4 6h16l-2 9H6zM9 19.5h.01M16 19.5h.01',
  truck: 'M2 7h12v9H2zM14 10h4l3 3v3h-7zM6 18.5h.01M17 18.5h.01',
  antenna: 'M12 21V11M8.5 7.5a5 5 0 017 0M5.5 4.5a9 9 0 0113 0M12 11a1.5 1.5 0 100-3 1.5 1.5 0 000 3z',
  gov: 'M3 21h18M5 21V10h14v11M9 21v-6h6v6M12 3l9 6H3z',
  bolt: 'M13 2L4 14h7l-1 8 9-12h-7z',
  star: 'M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 16.8 5.8 21.3l2.4-7.4L2 9.4h7.6z',
  grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
  users: 'M9 11a3 3 0 100-6 3 3 0 000 6zM3 20v-1a6 6 0 0112 0v1M16 5a3 3 0 010 6M21 20v-1a6 6 0 00-4-5.6',
  quote: 'M7 17V12c0-3 1.5-5 4-6M15 17V12c0-3 1.5-5 4-6M4 17h6M12 17h6',
  tag: 'M3 12V3h9l9 9-9 9zM7.5 7.5h.01',
  table: 'M4 5h16v14H4zM4 10h16M4 15h16M10 5v14',
  help: 'M12 21a9 9 0 100-18 9 9 0 000 18zM9.5 9a2.5 2.5 0 015 .5c0 1.5-2.5 2-2.5 3.5M12 17h.01',
  wrench: 'M14.7 6.3a4 4 0 00-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 005.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z',
  plug: 'M9 3v5M15 3v5M7 8h10v3a5 5 0 01-10 0zM12 16v5',
  gift: 'M4 11h16v10H4zM2 7h20v4H2zM12 7v14M12 7S10 3 7.5 3a2 2 0 000 4M12 7s2-4 4.5-4a2 2 0 010 4',
  ladder: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  steps: 'M5 4h4v4H5zM15 10h4v4h-4zM5 16h4v4H5zM9 6h3a2 2 0 012 2v2M15 14v2a2 2 0 01-2 2H9',
  send: 'M22 2L11 13M22 2l-7 20-4-9-9-4z',
  info: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 11v6M12 7h.01',
  target: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 17a5 5 0 100-10 5 5 0 000 10zM12 13a1 1 0 100-2 1 1 0 000 2z',
  clock: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2',
  building: 'M4 21V5l8-3v19M12 9h8v12M7 8h2M7 12h2M7 16h2M15 13h2M15 17h2',
  mail: 'M3 6h18v12H3zM3 7l9 6 9-6',
  briefcase: 'M3 7h18v13H3zM8 7V4h8v3M3 12h18',
  heartHand: 'M12 20s-7-4.5-7-10a4 4 0 017-2.6A4 4 0 0119 10c0 5.5-7 10-7 10z',
};

const SECTORS: [string, string][] = [['Banking', ic.bank], ['Insurance', ic.shield], ['Healthcare', ic.heart], ['Manufacturing', ic.factory], ['Retail', ic.cart], ['Logistics', ic.truck], ['Telecom', ic.antenna], ['Public sector', ic.gov], ['Utilities', ic.bolt]];
const STORY_FILTERS: [string, string][] = [['Financial services', ic.bank], ['Logistics', ic.truck], ['Healthcare', ic.heart], ['Insurance', ic.shield], ['Manufacturing', ic.factory], ['Retail', ic.cart]];

export const MENUS: Record<string, Menu> = {
  '/platform': {
    sections: [
      { heading: 'The four parts', links: [
        { label: 'Platform overview', desc: 'Build it. Run it. Govern it.', to: '/platform', icon: ic.overview },
        { label: 'One Agent Studio', desc: 'Design agents, or let AI draft them', to: '/platform#build', icon: ic.code },
        { label: 'One Runner', desc: 'Runs agents on your own machines', to: '/platform#run', icon: ic.play },
        { label: 'One Command Center', desc: 'Schedules, vault and audit', to: '/platform#govern', icon: ic.shield },
        { label: 'AI agents and One Workflow', desc: 'Agents and people, together', to: '/platform#orchestrate', icon: ic.network },
      ] },
      { heading: 'See how it works', links: [
        { label: 'Follow one invoice', desc: 'An agent, step by step', to: '/platform#walkthrough', icon: ic.doc },
        { label: 'How the parts work together', desc: 'From draft to audited run', to: '/platform#together', icon: ic.flow },
        { label: 'AI built in', desc: 'Agents, Prompt Skill and models', to: '/platform#ai', icon: ic.spark },
        { label: 'Security and deployment', desc: 'Self-hosted, encrypted, audited', to: '/platform#security', icon: ic.lock },
      ] },
    ],
    feature: { kicker: 'Live demo', title: 'See the platform run your process', text: 'In 30 minutes, an expert builds a live agent for a process like yours.', cta: 'Book a demo', to: '/contact' },
  },
  '/solutions': {
    sections: [
      { heading: 'By industry', cols: 2, links: SECTORS.map(([n, i]) => ({ label: n, to: `/solutions?sector=${encodeURIComponent(n)}#explorer`, icon: i })) },
      { heading: 'More', links: [
        { label: 'Use case spotlights', desc: 'Before and after an agent', to: '/solutions#spotlights', icon: ic.star },
        { label: 'Cross-industry processes', desc: 'Tasks every team automates first', to: '/solutions#cross', icon: ic.grid },
      ] },
    ],
    feature: { kicker: 'Where teams start', title: 'Most teams start with invoice processing', text: 'Pick one repetitive process. We show you the agent for it.', cta: 'Explore solutions', to: '/solutions#explorer' },
  },
  '/customers': {
    sections: [
      { heading: 'Customer stories', links: [
        { label: 'All stories', desc: 'What changed, and by how much', to: '/customers#stories', icon: ic.users },
        { label: 'In their own words', desc: 'What our customers say', to: '/customers#quotes', icon: ic.quote },
      ] },
      { heading: 'By industry', cols: 2, links: STORY_FILTERS.map(([n, i]) => ({ label: n, to: `/customers?filter=${encodeURIComponent(n)}#stories`, icon: i })) },
    ],
    feature: { kicker: 'Customer result', stat: '80%', title: 'faster invoice processing', text: 'A finance company cut processing from 3 days to 4 hours.', cta: 'Read the stories', to: '/customers#stories' },
  },
  '/pricing': {
    sections: [
      { heading: 'Plans', links: [
        { label: 'Community', desc: 'Free, for learners and builders', to: '/pricing#plans', icon: ic.code },
        { label: 'Starter', desc: 'For small teams', to: '/pricing#plans', icon: ic.play },
        { label: 'Business', desc: 'For departments scaling up', to: '/pricing#plans', icon: ic.grid },
        { label: 'Enterprise', desc: 'For automation at scale', to: '/pricing#plans', icon: ic.building },
      ] },
      { heading: 'Decide with confidence', links: [
        { label: 'Compare every plan', desc: 'Features side by side', to: '/pricing#compare', icon: ic.table },
        { label: 'Pricing questions', desc: 'Trials, currency, changes', to: '/pricing#faq', icon: ic.help },
      ] },
    ],
    feature: { kicker: 'Free to start', title: 'Start free. Upgrade when you’re ready.', text: 'Starter and Business include a free trial.', cta: 'See plans', to: '/pricing#plans' },
  },
  '/partners': {
    sections: [
      { heading: 'Partner types', links: [
        { label: 'Implementation partner', desc: 'Consultancies and integrators', to: '/partners#types', icon: ic.wrench },
        { label: 'Reseller partner', desc: 'IT providers and resellers', to: '/partners#types', icon: ic.tag },
        { label: 'Technology partner', desc: 'Software vendors and app builders', to: '/partners#types', icon: ic.plug },
      ] },
      { heading: 'The program', links: [
        { label: 'Partner benefits', desc: 'Pricing, training, sandbox', to: '/partners#benefits', icon: ic.gift },
        { label: 'Program levels', desc: 'Registered, Certified, Strategic', to: '/partners#levels', icon: ic.ladder },
        { label: 'How to become a partner', desc: 'Every step, who does what', to: '/partners#procedure', icon: ic.steps },
      ] },
    ],
    feature: { kicker: 'Partner Program', title: 'Your expertise. Our platform.', text: 'Our partner team replies within two business days.', cta: 'Become a partner', to: '/partners#apply' },
  },
  '/about': {
    sections: [
      { heading: 'Company', links: [
        { label: 'About us', desc: 'Who we are', to: '/about', icon: ic.info },
        { label: 'Mission and vision', desc: 'Why we automate', to: '/about#mission', icon: ic.target },
        { label: 'Our journey', desc: 'From 2021 to today', to: '/about#journey', icon: ic.clock },
      ] },
      { heading: 'People and contact', links: [
        { label: 'The teams behind it', desc: 'Engineering to customer success', to: '/about#teams', icon: ic.users },
        { label: 'Company information', desc: 'Registered office and CIN', to: '/about#info', icon: ic.building },
        { label: 'Contact us', desc: 'Sales, support and offices', to: '/contact', icon: ic.mail },
      ] },
    ],
    feature: { kicker: 'Offices', title: 'Karnataka, India and Doha, Qatar', text: 'Solution engineers in your time zone.', cta: 'Contact us', to: '/contact' },
  },
  '/careers': {
    sections: [
      { heading: 'Careers', links: [
        { label: 'Open roles', desc: 'Engineering, AI, solutions and more', to: '/careers#roles', icon: ic.briefcase },
        { label: 'Why join us', desc: 'Real problems, real ownership', to: '/careers#why', icon: ic.star },
        { label: 'How we hire', desc: 'Four simple steps', to: '/careers#hire', icon: ic.steps },
        { label: 'Send your CV', desc: 'We reply to everyone', to: '/careers#apply', icon: ic.send },
      ] },
    ],
    feature: { kicker: 'We’re hiring', title: 'Build intelligent automation with us', text: 'A small, focused team in India and Qatar.', cta: 'See open roles', to: '/careers#roles' },
  },
};
