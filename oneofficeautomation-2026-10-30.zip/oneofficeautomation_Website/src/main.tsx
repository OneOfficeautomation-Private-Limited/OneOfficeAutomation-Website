import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { AuthProvider } from './auth/AuthContext';
import { CmsProvider } from './cms/CmsContext';
import './index.css';
import './ds/ds.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <CmsProvider>
        <AuthProvider>
          <App />
        </AuthProvider>
      </CmsProvider>
    </BrowserRouter>
  </StrictMode>,
);
